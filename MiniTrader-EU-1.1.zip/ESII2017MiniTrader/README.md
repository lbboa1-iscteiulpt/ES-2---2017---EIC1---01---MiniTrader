Group 01 EIC1
Mariana Dias		68494	mrdso-iscteiulpt
Lucas Bártolo		70163	lbboa1-iscteiulpt
Bernardo Ribeiro	60802	bflro-iscteiulpt
Beatriz Luís 		68639 	bmlss-iscteiulpt

https://www.youtube.com/watch?v=aA1Qp-S-PHM&feature=youtu.be
