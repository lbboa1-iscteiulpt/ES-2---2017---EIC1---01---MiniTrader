package mt.filter;

public class ClientMessagesTimer {

	
	private String username;
	private long time;
	
	
	public ClientMessagesTimer(String username, long time){
		this.username=username;
		this.time=time;
	}


	public String getUsername() {
		return username;
	}


	public long getTime() {
		return time;
	}


	


}
