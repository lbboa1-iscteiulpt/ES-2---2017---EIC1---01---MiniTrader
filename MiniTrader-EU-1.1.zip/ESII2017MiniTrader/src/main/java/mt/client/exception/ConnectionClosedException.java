package mt.client.exception;

public class ConnectionClosedException extends Exception {

	public ConnectionClosedException(String message) {
		super(message);
	}

}
